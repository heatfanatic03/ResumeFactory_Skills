---
name: "resume-factory"
description: "Batch pipeline: run /remote-job-hunt (25 jobs), then build a tailored resume for every row via /gourmetresume, saving everything into one timestamped folder under GourmetResume\\resume_factory with the spreadsheet as the index."
---

# Resume Factory

One command, end to end: find 25 fresh remote jobs, then build a tailored resume for every one of them, all in a single dated folder with the spreadsheet as the index. The user may walk away after invoking this — run unattended, decide sensible defaults, and report at the end.

**Requires** the `remote-job-hunt` and `gourmetresume` skills and the user's `GourmetResume\baseline\` folder (`resume-master.docx`, `profile.md`, optionally `cover-letter-master.docx`). If any are missing, do the first-run setup described in `gourmetresume` section 0 before starting (this is the one time it's fine to ask questions up front).

## Output location

Root: `GourmetResume\resume_factory\` (device bridge: `$HOME/mnt/GourmetResume/resume_factory/` when that folder is connected).

Create one run folder named by the **request timestamp in the user's local timezone**, format `YYYY-MM-DD_HHMM` (24-hour time; two runs in the same minute get a `-2` suffix). Everything from this run goes inside it:

```
resume_factory/2026-10-23_0146/
  remote-job-hunt-2026-10-23.xlsx      <- the job-hunt spreadsheet, updated with build results (the index)
  README.txt                           <- run summary
  01 - Acme - Program Manager/
      Resume - Acme - Jane Doe.docx
      Cover Letter - Acme - Jane Doe.docx   (Greenhouse only, per gourmetresume rule)
      jd.txt
  02 - .../
  ...
```

Subfolder = `NN - <Company> - <Title>` (NN = row rank, zero-padded, ≤70 chars, none of `\ / : * ? " < > |`) so folder order matches the sheet. Inside each subfolder use gourmetresume's own file naming. Do **not** also write to `applications\`.

If the computer isn't linked, say so once, build everything under a sandbox folder `/root/w/factory/<timestamp>/`, zip the run folder, and deliver the zip plus the spreadsheet with SendUserFile.

## Procedure

### Phase 1 — Hunt (25 jobs)
1. Record the request timestamp and create the run folder (`device_bash mkdir -p`) before anything else.
2. Invoke the `remote-job-hunt` skill and follow it exactly — it returns 25 rows (22–28). If a prior factory run folder exists under `resume_factory/`, pass its spreadsheet in for dedupe so this run only builds new jobs.
3. Commit the spreadsheet into the run folder immediately (so the index exists even if the run is interrupted).

### Phase 2 — Build (batch mode for gourmetresume)
4. Stage the baseline masters (`resume-master.docx`, `cover-letter-master.docx` if present, `profile.md`) **once** into `/root/w/baseline/` and verify them per gourmetresume section 0 (zip integrity check). Every build tailors from these masters, never from a prior tailored copy.
5. **Build helper.** Write (or reuse if present) `/root/w/build_resume.py`. It takes a JSON spec (`out_dir`, `company`, optional `summary`, `competencies`, `bullets` {paragraph index: [bold lead-in, remainder]}, `move_after` [[src,dst]], `delete`, optional `cover_letter` {date, hook, role, company, connector, company_fit}), loads the master fresh, and applies run-level edits (map segments onto existing runs, never collapse into run[0]). It saves `Resume - <Company> - <Full Name>.docx` (+ cover letter), renders via `soffice --headless` → pypdf page count (resume = the master's page count, cover letter = 1), strips cover-letter highlight/color runs and asserts no `[placeholder]` text remains, runs a banned-term scan from profile.md's "Never claim" list, writes `build_report.json`, and exits 1 on any hard failure. Smoke-test it on one dummy spec before fan-out. Also write `/root/w/BUILD_BRIEF.md` with the master paragraph index map, the fact set, tailoring rules, cover-letter rule, fit-screen checklist, and the per-row report format.
6. **Fan out in waves.** If subagents are available, run 5 agents with 5 jobs each, all at once (25 rows = one wave). Each agent reads the brief, profile.md and the master, then builds its rows sequentially with the helper and looks at the rendered page images once per job. Without subagents, build the rows yourself in order. Each row reports: folder, Build Status, cover letter yes/no + ATS, JD verbatim yes/no, 1-line change summary, fit flags with numbers, hard gaps, pages.
7. **Batch-mode overrides of gourmetresume** (apply only inside resume-factory):
   - Section 6 "assess first, then ask which to build" does **not** apply — build every row without asking.
   - Never ask questions mid-run. Curl/python HTTP is usually blocked and WebFetch never returns verbatim JD text: read the JD via WebFetch (ATS page or API URL) as a structured capture, head `jd.txt` with `NOTE: structured capture, not verbatim`, and move on. Don't burn attempts chasing verbatim.
   - If a posting is closed/404 at build time: `Build Status = Skipped - closed`, no folder. If the ATS shows it >14 days old: build it but flag `stale` in Build Notes.
   - Hard blocker (active clearance, contractor-only, region lock excluding the user's location, degree gate, formal team-leadership years gate): still build, `Build Status = Built - FLAGGED`, blocker in Build Notes.
   - Cover-letter rule per profile.md's `cover_letter_policy` (default: automatic only for Greenhouse-hosted postings, including Greenhouse embeds on company sites). If the banned-term scan blocks a literal term in a cover letter, use the posting's shorthand and note it.
   - If profile.md has a positioning line, every spec's `summary` must be [role sentence 1] + the positioning line verbatim + [role sentence 3]. Copy the exact string into BUILD_BRIEF.md and have build_resume.py assert it is present.
   - All other gourmetresume rules stand: tailor only from master/profile facts, never invent, page-count assert, run-level docx edits, render check.
8. **Commit incrementally.** After each batch returns, record its rows in `build_results.json` and commit that batch's subfolders to the device (`device_commit_files`; stage via a helper that copies each folder minus `_render` to `/mnt/user-data/outputs/factory/`). A crash mid-run leaves finished resumes on disk.

### Phase 3 — Close out
9. Rebuild the spreadsheet with `Resume Folder`, `Build Status`, `Build Notes` filled on the **Jobs** tab (FLAGGED rows tinted), and add to **Summary**: built, built-flagged, skipped, cover letters, run duration. Recalculate and commit it to the run folder (force-overwrite the Phase-1 copy).
10. Write `README.txt`: timestamp, counts, **clean builds first** (rank, company, title, comp, folder name, one-line fit note), then every FLAGGED row with its blocker in one line, a TIME-SENSITIVE list (closing dates), STALENESS WARNINGS, GEOGRAPHY BLOCKERS, and a pointer to the Verified-Not-Built tab. Commit it.
11. Verify on the device with `device_bash`: count folders, `Resume - *.docx`, `Cover Letter - *.docx`, `jd.txt`.
12. Reply (short): run folder path, verified counts from step 11, counts (found / built / clean / flagged / skipped), the 5 highest-fit clean rows with folder names, time-sensitive closings, and one line on anything that limited the run. No step recap. Never claim files are on the user's computer unless the commit succeeded and step 11 confirmed it.

## Guardrails

- Generate and save only — never fill out or submit an application.
- Baseline masters are read-only; never commit anything back to `baseline\`.
- Build exactly the rows the hunt returned (22–28). If more than 28 come back, build the top 25 by fit and list the rest in README under "Not built"; if fewer than 15, still build them and say the pool was thin.
- Resume lint before any commit: banned-term scan passes, page count matches the master, no leftover highlight or placeholder runs in cover letters.
- If a cover-letter master template is used, letters may run longer than 350 words because its fixed text takes up space; keep hook/connector/fit tight and note it once in README rather than fighting it per row.
- If a build agent dies on a session usage limit, resume it with SendMessage after the reset rather than starting a new agent; nothing it already wrote is lost.
